<div class="pm-info">
    <p><?php echo __('Take payments via Ipay88 payment (redirect method).', 'traveler-ipay88') ?></p>
</div>