<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 15-10-2018
 * Time: 10:19 AM
 * Since: 1.0.0
 * Updated: 1.0.0
 */
if (!class_exists('ST_Ipay88_Payment_Gateway')) {
    class ST_Ipay88_Payment_Gateway extends STAbstactPaymentGateway
    {
        private $default_status = true;
        private $_gateway_id = 'st_ipay88';

        protected $gateway;
        protected $sandbox;
        protected $url;
        protected $merchantCode;
        protected $merchantKey;
        protected $hash_amount;
        protected $formatted_amount;

        public $types_mapping;
        public $types_mapping_ph;

        public function __construct()
        {
            add_filter('st_payment_gateway_st_ipay88_name', [$this, 'get_name']);

            $this->types_mapping = array(
                'image' => array(
                    '2' => 'credit-card',
                    '6' => 'maybank2u',
                    '8' => 'allianceonline',
                    '10' => 'ambank',
                    '14' => 'rhb	',
                    '15' => 'hongleong',
                    '20' => 'cimb',
                    '22' => 'webcash',
                    '31' => 'publicbank',
                    '48' => 'paypal',
                    '100' => 'celcomaircash',
                    '102' => 'bankrakyat',
                    '103' => 'affinbank',
                    '124' => 'bsn',
                    '134' => 'bankislam',
                    '152' => 'uobbankmy',
                ),
                'id' => array(
                    '2' => '_credit_card',
                    '6' => '_maybank2u',
                    '8' => '_alliance_online',
                    '10' => '_ambank',
                    '14' => '_rhb',
                    '15' => '_hong_leong_online',
                    '20' => '_cimb_click',
                    '22' => '_web_cash',
                    '31' => '_publicbank',
                    '48' => '_paypal',
                    '100' => '_celcomaircash',
                    '102' => '_bankrakyat',
                    '103' => '_affinbank',
                    '124' => '_bsn',
                    '134' => '_bankislam',
                    '152' => '_uobbankmy',
                )
            );

            $this->types_mapping_ph = array(
                'image' => array(
                    '1' => 'credit-card',
                    '5' => 'bancnet',
                    '6' => 'paypal',
                ),
                'id' => array(
                    '1' => '_credit_card',
                    '5' => '_bancnet',
                    '6' => '_paypal',

                )
            );

            add_action('init', [$this, 'backendResponsive']);
        }

        public function setDefaultParameters()
        {
            $this->gateway = st()->get_option('gateway_ipay88');
            $this->merchantCode = st()->get_option('merchant_code_ipay88');
            $this->merchantKey = st()->get_option('merchant_key_ipay88');
            $this->sandbox = st()->get_option('test_mode_ipay88', 'on');
            if ('PH' == $this->gateway) {
                if ('on' == $this->sandbox) {
                    $this->url = 'https://sandbox.ipay88.com.ph/epayment/entry.asp';
                } else {
                    $this->url = 'https://payment.ipay88.com.ph/epayment/entry.asp';
                }
            } else {
                $this->url = 'https://www.mobile88.com/epayment/entry.asp';
            }
        }

        function get_default_status()
        {
            return $this->default_status;
        }

        function get_name()
        {
            return __('Ipay88', 'traveler-ipay88');
        }

        function _pre_checkout_validate()
        {
            return true;
        }

        function get_option_fields()
        {
            return [
                [
                    'id' => 'gateway_ipay88',
                    'label' => esc_html__('Gateway', 'traveler-ipay88'),
                    'type' => 'select',
                    'choices' => [
                        [
                            'label' => esc_html__('Malaysia', 'traveler-ipay88'),
                            'value' => 'MY'
                        ],
                        [
                            'label' => esc_html__('Philippines', 'traveler-ipay88'),
                            'value' => 'PH'
                        ],
                    ],
                    'desc' => esc_html__('Which iPay88 gateway are you using? Currently supported are Malaysia and Philippines.', 'traveler-ipay88'),
                    'section' => 'option_pmgateway',
                ],
                [
                    'id' => 'test_mode_ipay88',
                    'label' => esc_html__('Test Mode', 'traveler-ipay88'),
                    'type' => 'on-off',
                    'std' => 'on',
                    'desc' => esc_html__('Sandbox mode provides you with a chance to test your gateway integration with iPay88. The payment requests will be send to the iPay88 sandbox URL. Disable to start accepting Live payments.', 'traveler-ipay88'),
                    'condition' => 'gateway_ipay88:is(PH)',
                    'section' => 'option_pmgateway'
                ],
                [
                    'id' => 'merchant_code_ipay88',
                    'label' => esc_html__('Merchant Code', 'traveler-ipay88'),
                    'type' => 'text',
                    'section' => 'option_pmgateway'
                ],
                [
                    'id' => 'merchant_key_ipay88',
                    'label' => esc_html__('Merchant Key', 'traveler-ipay88'),
                    'type' => 'text',
                    'section' => 'option_pmgateway'
                ],
                [
                    'id' => 'paymenttype_available_ipay88',
                    'label' => esc_html__('Payment Available', 'traveler-ipay88'),
                    'type' => 'checkbox',
                    'choices' => [
                        [
                            'label' => esc_html__('Credit Card', 'traveler-ipay88'),
                            'value' => 2
                        ],
                        [
                            'label' => esc_html__('Maybank2U', 'traveler-ipay88'),
                            'value' => 6
                        ],
                        [
                            'label' => esc_html__('Alliance Online', 'traveler-ipay88'),
                            'value' => 8
                        ],
                        [
                            'label' => esc_html__('AmBank', 'traveler-ipay88'),
                            'value' => 10
                        ],
                        [
                            'label' => esc_html__('RHB', 'traveler-ipay88'),
                            'value' => 14
                        ],
                        [
                            'label' => esc_html__('Hong Leong Online', 'traveler-ipay88'),
                            'value' => 15
                        ],
                        [
                            'label' => esc_html__('CIMB Click', 'traveler-ipay88'),
                            'value' => 20
                        ],
                        [
                            'label' => esc_html__('Web Cash', 'traveler-ipay88'),
                            'value' => 22
                        ],
                        [
                            'label' => esc_html__('Public Bank Online', 'traveler-ipay88'),
                            'value' => 31
                        ],
                        [
                            'label' => esc_html__('PayPal', 'traveler-ipay88'),
                            'value' => 48
                        ],
                        [
                            'label' => esc_html__('Celcom AirCash', 'traveler-ipay88'),
                            'value' => 100
                        ],
                        [
                            'label' => esc_html__('Bank Rakyat', 'traveler-ipay88'),
                            'value' => 102
                        ],
                        [
                            'label' => esc_html__('AffinBank', 'traveler-ipay88'),
                            'value' => 103
                        ],
                        [
                            'label' => esc_html__('BSN Online', 'traveler-ipay88'),
                            'value' => 124
                        ],
                        [
                            'label' => esc_html__('BankIslam Online', 'traveler-ipay88'),
                            'value' => 134
                        ],
                        [
                            'label' => esc_html__('UOB Bank Online', 'traveler-ipay88'),
                            'value' => 152
                        ],
                    ],
                    'condition' => 'gateway_ipay88:is(MY)',
                    'section' => 'option_pmgateway'
                ],
                [
                    'id' => 'paymenttype_available_ph_ipay88',
                    'label' => esc_html__('Payments Available', 'traveler-ipay88'),
                    'type' => 'checkbox',
                    'choices' => [
                        [
                            'label' => esc_html__('Credit Card', 'traveler-ipay88'),
                            'value' => 1
                        ],
                        [
                            'label' => esc_html__('BancNet', 'traveler-ipay88'),
                            'value' => 5
                        ],
                        [
                            'label' => esc_html__('PayPal', 'traveler-ipay88'),
                            'value' => 6
                        ],
                    ],
                    'condition' => 'gateway_ipay88:is(PH)',
                    'section' => 'option_pmgateway'
                ],
                [
                    'id' => 'ipay88_des',
                    'label' => esc_html__('Description', 'traveler-ipay88'),
                    'type' => 'textarea-simple',
                    'rows' => 5,
                    'desc' => esc_html__('Enter some details for this payment', 'traveler-ipay88'),
                    'section' => 'option_pmgateway'
                ],
            ];
        }

        function do_checkout($order_id)
        {
            $payment = STInput::post('st_payment_gateway');
            $paymentType = STInput::post('paymentcode');
            if ($payment != 'st_ipay88' || ($payment == 'st_ipay88' && !$paymentType)) {
                return [
                    'status' => false,
                    'message' => __('Can not create payment URL.', 'traveler-ipay88')
                ];
            }

            $this->setDefaultParameters();

            $params = $this->get_purchase_data($order_id);
            $ipay88_form_array = array();

            foreach ($params as $key => $value) {
                $ipay88_form_array[] = '<input type="hidden" name="' . esc_attr($key) . '" value="' . esc_attr($value) . '" />';
            }
            $form = sprintf('<h4>Redirecting....</h4>
             <form action="%s" method="post" id="st_form_ipay88_submit">%s</form>
    						<script>document.getElementById(\'st_form_ipay88_submit\').submit();</script>', $this->url, implode('', $ipay88_form_array));

            return [
                'status' => true,
                'redirect_form' => $form
            ];

        }

        private function get_purchase_data($new_order)
        {
            $total = get_post_meta($new_order, 'total_price', true);
            $total = round((float)$total, 2);

            $amount = $this->convert_price($total);
            $this->format_amount($amount);
            $service_id = (int)get_post_meta($new_order, 'item_id', true);

            $first_name = get_post_meta($new_order, 'st_first_name', true);
            $last_name = get_post_meta($new_order, 'st_last_name', true);
            $email_address = get_post_meta($new_order, 'st_email', true);
            $phone = get_post_meta($new_order, 'st_phone', true);

            $params = array(
                'MerchantCode' => $this->merchantCode,
                'RefNo' => $new_order,
                'Amount' => $this->formatted_amount,
                'Currency' => TravelHelper::get_current_currency('name'),
                'ProdDesc' => get_the_title($service_id),
                'UserName' => $first_name . ' ' . $last_name,
                'UserEmail' => $email_address,
                'UserContact' => $phone,
                'ResponseURL' => $this->get_return_url($new_order),
                'BackendURL' => $this->get_return_url($new_order),
            );;
            $payment_type = STInput::post('paymentCode');
            $payment_type = str_replace('ipay88-', '', $payment_type);
            if (null != $payment_type && 0 != $payment_type) {
                $params['PaymentId'] = $payment_type;
            }
            $params['signature'] = $this->generate_sha1_signature($params, false);
            return $params;

        }

        public function convert_price($price, $check = false)
        {
            $price = round($price, 2);
            if ($check) {
                return number_format($price, 2, '', '');
            }

            return $price;
        }

        public function format_amount($amount)
        {
            if (is_numeric($amount)) {
                $this->hash_amount = number_format($amount, 2, '', '');
                $this->formatted_amount = number_format($amount, 2, '.', ',');
            }
        }

        public function hex2bin($hexSource)
        {
            $bin = '';
            for ($i = 0; $i < strlen($hexSource); $i = $i + 2) {
                $bin .= chr(hexdec(substr($hexSource, $i, 2)));
            }

            return $bin;
        }

        private function generate_sha1_signature($params, $is_response = true)
        {
            if ($is_response) {
                $this->format_amount(str_replace(',', '', $params['Amount']));
                $string = $params['PaymentId'] . $params['RefNo'] . $this->hash_amount . $params['Currency'] . $params['Status'];
            } else {
                $string = $params['RefNo'] . $this->hash_amount . $params['Currency'];
            }

            $string = $this->merchantKey . $this->merchantCode . $string;

            return base64_encode($this->hex2bin(sha1($string)));
        }

        function complete_purchase($order_id)
        {
            return true;
        }

        function check_complete_purchase($order_id)
        {
            $this->setDefaultParameters();
            if ($this->validate_response($order_id)) {
                $estatus = (isset($_POST['Status'])) ? $_POST['Status'] : 0;

                switch ($estatus) :
                    case 1 :
                        return [
                            'status' => true
                        ];
                        break;
                    case 2 :
                    default :
                        return [
                            'status' => false,
                            'message' => $_POST['ErrDesc']
                        ];
                        break;
                endswitch;

            } else {
                return [
                    'status' => false,
                    'message' => __('Transaction error, please contact support center', 'traveler-ipay88')
                ];
            }
        }

        public function backendResponsive()
        {
            if (isset($_GET['backendResponsive']) && $_GET['backendResponsive'] == 'ipay88' && isset($_GET['orderID'])) {
                $this->setDefaultParameters();
                if ($this->validate_response($_GET['orderID'])) {
                    $order_id = $_GET['orderID'];
                    $estatus = (isset($_POST['Status'])) ? $_POST['Status'] : 0;

                    switch ($estatus) :
                        case 1 :
                            update_post_meta($order_id, 'status', 'complete');
                            STCart::send_mail_after_booking($order_id, true);
                            do_action('st_booking_change_status', 'complete', $order_id, 'st_ipay88');
                            break;
                        case 2 :
                        default :
                            return false;
                            break;
                    endswitch;

                } else {
                    return false;
                }
            }
        }

        public function validate_response($order_id)
        {
            $signature = $this->generate_sha1_signature($_POST);
            if (STInput::post('Signature') == $signature) {
                $total = get_post_meta($order_id, 'total_price', true);
                $total = round((float)$total, 2);
                $order_total = $this->convert_price($total, true);
                if (abs($order_total - $this->hash_amount) == 0) {
                    return true;
                }

                return false;

            } else {

                return false;
            }

        }

        function is_available($item_id = false)
        {
            if (st()->get_option('pm_gway_st_ipay88_enable') == 'off') {
                return false;
            }

            return true;
        }

        function getGatewayId()
        {
            return $this->_gateway_id;
        }

        function is_check_complete_required()
        {
            return true;
        }

        function get_logo()
        {
            return Traveler_Ipay88_Payment::get_inst()->pluginUrl . 'assets/img/ipay88.png';
        }

        function html()
        {
            echo Traveler_Ipay88_Payment::get_inst()->loadTemplate('ipay');
        }

        function get_return_url($order_id, $backend = false)
        {
            $order_token_code = get_post_meta($order_id, 'order_token_code', TRUE);
            if (!$order_token_code) {
                $array = [
                    'gateway_name' => $this->getGatewayId(),
                    'order_code' => $order_id,
                    'status' => TRUE
                ];
            } else {
                $array = [
                    'gateway_name' => $this->getGatewayId(),
                    'order_token_code' => $order_token_code,
                    'status' => TRUE
                ];

            }
            if ($backend) {
                $array['backendResponsive'] = 'ipay88';
                $array['orderID'] = $order_id;
            }

            return add_query_arg($array, STCart::get_success_link());

        }

        public static function get_inst()
        {
            static $instance;
            if (is_null($instance)) {
                $instance = new self();
            }

            return $instance;
        }

        public static function add_payment($payment)
        {
            $payment['st_ipay88'] = self::get_inst();

            return $payment;
        }
    }
    add_filter('st_payment_gateways', ['ST_Ipay88_Payment_Gateway', 'add_payment']);
}